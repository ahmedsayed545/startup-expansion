#!/usr/bin/env python
# coding: utf-8

# ## Data Analysis startup-expansion

# In[64]:


import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 
import seaborn as sns 
get_ipython().run_line_magic('matplotlib', 'inline')


# In[65]:


data = pd.read_excel('E:\projects upwork\startup_expansion\startup-expansion.xlsx')
data.head(10)


# In[66]:


data.shape


# In[67]:


data.columns


# In[68]:


data.dtypes


# In[69]:


data.info()


# In[70]:


data[['Marketing Spend','Revenue']].describe().round(2)


# # processing Data

# In[71]:


data['City'].unique()


# In[72]:


data['City'].nunique()


# In[73]:


data['City'].value_counts()


# In[74]:


data['State'].unique()


# In[75]:


data['State'].nunique()


# In[76]:


data['State'].value_counts()


# In[77]:


data['Sales Region'].unique()


# In[78]:


data['Sales Region'].value_counts()


# In[79]:


data['New Expansion'].unique()


# In[80]:


data['New Expansion'].value_counts()


# In[81]:


data.isnull().sum()


# In[82]:


data.duplicated().sum()


# ## good news no null or duplicated

# ## Exploring & Analysing Data 

# In[83]:


data.sample(10)


# ## Q1  number of stores in each region 

# In[84]:


data['Sales Region'].value_counts().plot.bar()


# In[85]:


data[data['New Expansion']=='New'].groupby('State').sum()['Revenue'].nlargest(10)


# In[86]:


data[data['New Expansion']=='Old'].groupby('State').sum()['Revenue'].nlargest(10)


# In[87]:


#data['ROI'] =round((data['Revenue']/data['Marketing Spend'])* 100,2) # Return of markating Spend


# In[89]:


data['Profit'] = data['Revenue']-data['Marketing Spend']
data


# In[92]:


data['ROMS'] = round(data['Profit']/data['Marketing Spend'] * 100 ,2)
data


# In[94]:


data.to_csv('E:\projects upwork\startup_expansion\startup-expansion.csv')
data

